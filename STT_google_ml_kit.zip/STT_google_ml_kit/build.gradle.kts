// build.gradle.kts (DI DIREKTORI UTAMA PROYEK)
// JANGAN tambahkan konten lain di sini.
// Cukup deklarasikan alias plugin.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.jetbrains.kotlin.android) apply false
}